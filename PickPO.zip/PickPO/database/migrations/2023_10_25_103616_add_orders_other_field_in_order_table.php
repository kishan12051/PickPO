<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddOrdersOtherFieldInOrderTable extends Migration
{
    public function up()
    {
        Schema::table('order', function (Blueprint $table) {
            $table->decimal('order_sub_total', 10, 2)->after('status');
            $table->decimal('order_discount', 10, 2)->after('order_sub_total');
            $table->decimal('order_tax', 10, 2)->after('order_discount');
            $table->decimal('order_delivery_fee', 10, 2)->after('order_tax');
            $table->decimal('order_total', 10, 2)->after('order_delivery_fee');
            $table->unsignedBigInteger('coupon_id')->nullable()->after('order_total');
        });
    }

    public function down()
    {
        Schema::table('order', function (Blueprint $table) {
            $table->dropColumn('order_sub_total');
            $table->dropColumn('order_discount');
            $table->dropColumn('order_tax');
            $table->dropColumn('order_delivery_fee');
            $table->dropColumn('order_total');
            $table->dropColumn('coupon_id');
        });
    }
}
