<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductStateVisibility extends Model
{
    use HasFactory;
    protected $table = 'products_state_visibility';
     protected $fillable = [
        'product_id','state_id'
    ];
}
