<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\State;

class StateController extends Controller
{
    public function index()
    {
        $state = State::select()->orderBy('id', 'desc')->where('isActive', '1')->get();
        return view('state.state', compact('state'));
    }

    public function create()
    {
        return view('state.stateadd');
    }
    public function store(Request $request)
    {
        $this->validate($request, [
            'state' => 'required|string',
            'status' => 'required|in:1,2'
        ]);

        State::create([
            'state' => $request->state,
            'status' => $request->status
        ]);

        return redirect()->intended('state')->with('message', 'Data stored successfully');
    }

    public function show($id)
    {
        $stateData = State::select()->where('id', $id)->first()->toArray();
        return view('state.stateshow', compact('stateData'));
    }

    public function edit($id)
    {
        $stateData = State::select()->where('id', $id)->first()->toArray();
        return view('state.stateedit', compact('stateData'));
    }
    public function update(Request $request)
    {

        $this->validate($request, [
            'state' => 'required|string',
            'status' => 'required|in:1,2',
        ]);

        $stateData = State::where('id', $request->id)->update([
            'state' => $request->state,
            'status' => $request->status
        ]);

        return redirect()->intended('state')->with('message', 'Data updated successfully');
    }

    public function delete(Request $request)
    {
        State::select()->where('id', $request->id)->update(['isActive' => "0"]);
        return back();
    }
}
