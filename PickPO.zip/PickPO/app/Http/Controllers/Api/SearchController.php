<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\MasterCategory;
use App\Models\MainCategory;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\ProductsImage;
use App\Models\ProductAllCategory;
use App\Models\ProductStateVisibility;
use App\Models\Address;
use Auth;

class SearchController extends Controller
{
    public function searchData(Request $request)
    {
        $baseUrl = \Config::get('baseurl');

        if ($request->search) {
            $userId = Auth::user()->id;

            $userAddress = Address::where('user_id', $userId)->where('default_address', 1)->first();

            $userState = $userAddress->state_id;

            $productData = [];
            $masterCategoryData = [];
            $mainCategoryData = [];
            $categoryData = [];
            $subCategoryData = [];

            // Search for products matching the search query
            $products = Product::where('product_name', 'like', '%' . $request->search . '%')->where('isActive', '1')->get();

            foreach ($products as $product) {
                // Check state visibility restriction for the product
                $getStateVisibilityCount = ProductStateVisibility::where('product_id', $product->id)
                    ->where('state_id', $userState)
                    ->count();

                if ($getStateVisibilityCount == 0) {
                    // If the product is not restricted in the user's state, add it to the results
                    $productImage = ProductsImage::select()->where('product_id', $product->id)->get()->toArray();
                    $product_image = str_replace('\\', '/', $productImage[0]['product_image']);
                    $productData[] = array(
                        'product_id' => $product->id,
                        'product_name' => $product->product_name,
                        'product_image' => $baseUrl['base_url'] . $product_image,
                        'product_price' => $product->product_price,
                        'sale_price' => isset($product->sale_price) ? $product->sale_price : '0',
                        'sale' => $product->sale,
                        'quantity' => $product->quantity,
                    );
                }
            }

            $masterCategory = MasterCategory::select()->where('master_category_name', 'like', '%' . $request->search . '%')->where('isActive', '1')->get()->toArray();

            foreach ($masterCategory as $mastercategory) {
                // Check if there are products in this master category
                $getProductfromMasterCategory = ProductAllCategory::select('*')
                    ->join('products', 'products.id', '=', 'products_all_category.product_id')
                    ->where('mastercategory_id', $mastercategory['id'])
                    ->where('maincategory_id', 0)
                    ->where('products.status', 1)
                    ->where('products.isActive', '1')
                    ->limit(10)
                    ->get()->toArray();

                if (!empty($getProductfromMasterCategory)) {
                    $master_category_image = str_replace('\\', '/', $mastercategory['master_category_image']);
                    $masterCategoryData[] = array(
                        'mastercategory_id' => $mastercategory['id'],
                        'master_category_name' => $mastercategory['master_category_name'],
                        'master_category_image' => $baseUrl['base_url'] . $master_category_image,
                    );
                }
            }

            $mainCategory = MainCategory::select()->where('main_category_name', 'like', '%' . $request->search . '%')->where('isActive', '1')->get()->toArray();

            foreach ($mainCategory as $maincategory) {
                // Check if there are products in this main category
                $getProductfromMainCategory = ProductAllCategory::select('*')
                    ->join('products', 'products.id', '=', 'products_all_category.product_id')
                    ->where('maincategory_id', $maincategory['id'])
                    ->where('products.status', 1)
                    ->where('products.isActive', '1')
                    ->limit(10)
                    ->get()->toArray();

                if (!empty($getProductfromMainCategory)) {
                    $mainCategoryData[] = array(
                        'maincategory_id' => $maincategory['id'],
                        'main_category_name' => $maincategory['main_category_name'],
                    );
                }
            }

            $category = Category::select()->where('category_name', 'like', '%' . $request->search . '%')->where('isActive', '1')->get()->toArray();

            foreach ($category as $categoryItem) {
                // Check if there are products in this category
                $getProductfromCategory = ProductAllCategory::select('*')
                    ->join('products', 'products.id', '=', 'products_all_category.product_id')
                    ->where('category_id', $categoryItem['id'])
                    ->where('subcategory_id', 0)
                    ->where('products.status', 1)
                    ->where('products.isActive', '1')
                    ->limit(10)
                    ->get()->toArray();

                if (!empty($getProductfromCategory)) {
                    $categoryData[] = array(
                        'category_id' => $categoryItem['id'],
                        'category_name' => $categoryItem['category_name'],
                    );
                }
            }

            $subCategory = SubCategory::select()->where('sub_category_name', 'like', '%' . $request->search . '%')->where('isActive', '1')->get()->toArray();

            foreach ($subCategory as $subcategoryItem) {
                $getProductfromSubCategory = ProductAllCategory::select('*')
                    ->join('products', 'products.id', '=', 'products_all_category.product_id')
                    ->where('subcategory_id', $subcategoryItem['id'])
                    ->where('products.status', 1)
                    ->where('products.isActive', '1')
                    ->limit(10)
                    ->get()->toArray();

                if (!empty($getProductfromSubCategory)) {
                    $subCategoryData[] = array(
                        'subcategory_id' => $subcategoryItem['id'],
                        'subcategory_name' => $subcategoryItem['sub_category_name'],
                    );
                }
            }

            $data = array();
            if (count($productData) > 0) {
                $data['product'] = $productData;
            }
            if (!empty($masterCategoryData)) {
                $data['master_category'] = $masterCategoryData;
            }
            if (!empty($mainCategoryData)) {
                $data['main_category'] = $mainCategoryData;
            }
            if (!empty($categoryData)) {
                $data['category'] = $categoryData;
            }
            if (!empty($subCategoryData)) {
                $data['subcategory'] = $subCategoryData;
            }

            $countData = count($productData) + count($masterCategoryData) + count($mainCategoryData) + count($categoryData) + count($subCategoryData);

            if ($countData > 0) {
                return response()->json([
                    "search_data" => $data,
                    "success" => true,
                    "messagecode" => 1,
                    "message" => $countData . ' result(s) for "' . $request->search . '"',
                ]);
            } else {
                return response()->json([
                    "success" => true,
                    "message" => "Data not Found",
                ]);
            }

        } else {
            $validator = Validator::make($request->all(), [
                'search' => 'required',
            ]);

            if ($validator->fails()) {
                return response(['error' => $validator->errors(),
                    'Validation Error']);
            }

        }
    }
}
