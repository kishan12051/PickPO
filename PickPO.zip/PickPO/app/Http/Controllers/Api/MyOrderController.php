<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\CartProduct;
use App\Models\Order;
use App\Models\User;
use App\Models\Coupon;
use App\Models\UserCoupon;
use App\Models\ProductsImage;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class MyOrderController extends Controller
{
    public function myOrder(Request $request)
    {
        $userId = Auth::user()->id;

        if ($request->day || $request->month || $request->year) {

            $baseUrl = \Config::get('baseurl');

            /*get pending products data*/
            $cartAndProductData = Order::select('order.id', 'order.cart_id', 'order.user_id', 'order.status', 'order.created_at', 'order.updated_at', DB::raw('count(*) as total'))
                ->join('cart_product', 'cart_product.cart_id', '=', 'order.cart_id')
                ->where('order.user_id', $userId)
                ->groupBy('order.id', 'order.cart_id', 'order.user_id', 'order.status', 'order.created_at', 'order.updated_at')
                ->where('order.status', 1);

            /*get delivered products data*/
            $cartAndProduct = Order::select('order.id', 'order.cart_id', 'order.user_id', 'order.status', 'order.created_at', 'order.updated_at', DB::raw('count(*) as total'))
                ->join('cart_product', 'cart_product.cart_id', '=', 'order.cart_id')
                ->where('order.user_id', $userId)
                ->groupBy('order.id', 'order.cart_id', 'order.user_id', 'order.status', 'order.created_at', 'order.updated_at')
                ->where('order.status', 2);

            if ($request->day) {
                $date = \Carbon\Carbon::now()->subDays($request->day)->endOfDay();
                $cartAndProduct->where('order.created_at', '>=', $date);
                $cartAndProductData->where('order.created_at', '>=', $date);
            }

            if ($request->month) {
                $month = \Carbon\Carbon::now()->subMonths($request->month);
                $cartAndProduct->where('order.created_at', '>=', $month->format('m'));
                $cartAndProductData->where('order.created_at', '>=', $month->format('m'));
            }

            if ($request->year) {
                $cartAndProduct->whereYear('order.created_at', $request->year);
                $cartAndProductData->whereYear('order.created_at', $request->year);
            }

            $orderPendingData = $cartAndProductData->get()->toArray();
            $orderDeliveredData = $cartAndProduct->get()->toArray();

            $pendingData = [];

            foreach ($orderPendingData as $key => $orderDetails) {

                $pendingProductDetail = Order::select('cart_product.product_id','productsimage.product_image')
                    ->join('cart_product', 'cart_product.cart_id', '=', 'order.cart_id')
                    ->join('productsimage', 'productsimage.product_id', '=', 'cart_product.product_id')
                    ->where('order.id', $orderDetails['id'])
                    ->where('order.user_id', $userId)
                    ->where('order.status', 1)
                    ->get()->toArray();
  
                $pendingData[] = [
                    'order_id' => $orderDetails['id'],
                    'date' => $orderDetails['created_at'],
                    'total_product' => $orderDetails['total'],
                    'product_image' => $baseUrl['base_url'] . $pendingProductDetail[0]['product_image'],
                ];
            }

            $deliveredData = [];

            foreach ($orderDeliveredData as $key1 => $orderDetails) {

                $deleiveredProductDetail = Order::select('cart_product.product_id','productsimage.product_image')
                    ->join('cart_product', 'cart_product.cart_id', '=', 'order.cart_id')
                    ->join('productsimage', 'productsimage.product_id', '=', 'cart_product.product_id')
                    ->where('order.id', $orderDetails['id'])
                    ->where('order.user_id', $userId)
                    ->where('order.status', 2)
                    ->get()->toArray();
                   
                $deliveredData[] = [
                    'order_id' => $orderDetails['id'],
                    'date' => $orderDetails['created_at'],
                    'total_product' => $orderDetails['total'],
                    'product_image' => $baseUrl['base_url'] . $deleiveredProductDetail[0]['product_image'],
                ];
           
            }

            return response()->json([
                'success' => true,
                'messagecode' => "Successful",
                'pending_order' => $pendingData,
                'delivered_order' => $deliveredData
            ]);
        } else {
            $validator = Validator::make($request->all(), [
                'day' => 'required_without_all:month,year',
                'month' => 'required_without_all:day,year',
                'year' => 'required_without_all:day,month',
            ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 401);
            }
        }
    }

    public function pendingDeliveredOrder(Request $request)
    {
        $userId = Auth::user()->id;

        $validator = Validator::make($request->all(), [
            'order_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response([
                'error' => $validator->errors(),
                'Validation Error',
            ]);
        }

        $orderBelongsToCurrentUser = Order::where('id', $request->order_id)
            ->where('user_id', $userId)
            ->exists();

        if (!$orderBelongsToCurrentUser) {
            return response([
                'error' => 'Order does not belong to the current user.',
            ], 403);
        }

        $orderData = Order::select('order.id', 'cart_product.cart_id', 'cart_product.product_id', 'products.id', 'products.product_name', 'products.product_price', 'cart_product.product_quantity', 'order.status AS order_status', 'order.reward_status AS order_reward_status', DB::raw('count(*) as total'))
            ->join('cart_product', 'cart_product.cart_id', '=', 'order.cart_id')
            ->join('products', 'products.id', '=', 'cart_product.product_id')
            ->where('order.id', $request->order_id)
            ->where('order.user_id', $userId)
            ->groupBy('order.id', 'order.reward_status', 'order.status', 'cart_product.cart_id', 'cart_product.product_id', 'products.id', 'products.product_name', 'products.product_price', 'cart_product.product_quantity')
            ->get()
            ->toArray();

        $productData = array();
        $data = array();
        $order_status = "";
        $totalProduct = 0;
        $rewardPointsToAdd = 0;

        foreach ($orderData as $key => $getData) {
            $baseUrl = \Config::get('baseurl');
            $productImage = ProductsImage::select()->where('product_id', $getData['product_id'])->get()->toArray();
            $product_image = str_replace('\\', '/', $productImage[0]['product_image']);
            $productData[] = array(
                'product_id' => $getData['product_id'],
                'product_name' => $getData['product_name'],
                'product_price' => $getData['product_price'],
                'product_image' => $baseUrl['base_url'] . $product_image,
                'total_price' => $getData['product_price'] * (int) $getData['product_quantity'],
            );

            if ($getData['order_status'] == 1 && $getData['order_reward_status'] == 1) {
                // Calculate reward points to be earned for this pending order
                $status = "pending";
                $rewardPointsToAdd = 0;
                $rewardPointsToWillGet = floor($getData['product_price'] * (int) $getData['product_quantity']) / 100;
            } else {
                $status = "delivered";
                $orderRewardStatusUpdate = order::select()
                    ->where('user_id', $userId)
                    ->where('status', 2)
                    ->where('id', $request->order_id)
                    ->update(array('reward_status' => 2));
                if ($getData['order_reward_status'] == 1) {
                    $rewardPointsToAdd += $this->calculateRewardPoints($getData['product_price'] * (int) $getData['product_quantity']);
                } else {
                    $rewardPointsToAdd = 0;
                }
            }
            $totalProduct += $getData['total'];
        }

        // Update user's reward points if reward points are earned
        if ($rewardPointsToAdd > 0) {
            $user = User::find($userId);
            $user->reward_points += $rewardPointsToAdd;
            $user->save();
        }

        // Get the total reward points of the user
        $user = User::find($userId);
        $totalRewardPoints = $user->reward_points;

        $total = 0;
        $totalPrice = array();

        foreach ($productData as $productDataValue) {
            $total += $productDataValue['total_price'];
            $totalPrice[] = $total;
            $data['sub_total'] = $total;
            $data['delivery_fee'] = 0;
            $data['tax'] = 0;
            $data['order_total'] = $total;
        }

        if ($status == "pending") {
            // Calculate reward points to be earned for this pending order
            $rewardPointsToWillGet = intval($total / 100);
            $dd = $totalRewardPoints + $rewardPointsToWillGet;
            return response()->json([
                "success" => true,
                "messagecode" => "Successful",
                "status" => $status,
                "total_product" => $totalProduct,
                "product" => $productData,
                "product_sub_total" => $data,
                "reward_points_after_order " => $rewardPointsToWillGet,
                "after_order_total_reward_points" => $dd,
                "currunt_reward_points " => $totalRewardPoints,
            ]);

        } else {
            // Calculate reward points to add when the order is delivered
            $rewardPointsToAdd = intval($total / 100);
            return response()->json([
                "success" => true,
                "messagecode" => "Successful",
                "status" => $status,
                "total_product" => $totalProduct,
                "product" => $productData,
                "product_sub_total" => $data,
                "reward_points_was_added" => $rewardPointsToAdd,
                "currunt_reward_points" => $totalRewardPoints,
            ]);
        }
    }

    private function calculateRewardPoints($orderAmount)
    {
        // Calculate reward points based on order amount and your rule
        $rewardPoints = floor($orderAmount / 100);
        return $rewardPoints;
    }

    public function order(Request $request)
    {
        $userId = Auth::user()->id;

        // Validate the request
        $validator = Validator::make($request->all(), [
            'cart_id' => 'required',
            'tax' => 'required',
            'delivery_fee' => 'required',
            'coupon_id' => 'nullable|exists:coupons,id',
        ]);

        if ($validator->fails()) {
            return response(['error' => $validator->errors(), 'Validation Error']);
        }

        // Check if the cart exists and is not already ordered
        $getCart = Cart::where('user_id', $userId)
            ->where('status', 1)
            ->where('id', $request->cart_id)
            ->first();

        if (!$getCart) {
            return response([
                'success' => false,
                'message' => 'Invalid Cart Id or Cart is already ordered.',
            ], 200);
        }

        // Fetch order data - replace this with your logic to retrieve the relevant data for the order
        $orderData = CartProduct::select(
            'cart_product.product_id',
            'products.product_price',
            'cart_product.product_quantity',
        )
            ->join('products', 'products.id', '=', 'cart_product.product_id')
            ->join('cart', 'cart.id', '=', 'cart_product.cart_id')
            ->where('cart_product.cart_id', $getCart->id)
            ->get();

        // Calculate coupon discount
        $couponDiscount = 0;
        $subTotal = 0;
        // Calculate the sub total based on the products in the cart

        foreach ($orderData as $getData) {
            $subTotal += $getData->product_price * $getData->product_quantity;
        }

        if ($request->has('coupon_id')) {
            $coupon = UserCoupon::join('coupons', 'coupons.id', '=', 'usercoupons.coupon_id')
                ->where('usercoupons.user_id', $userId)
                ->where('coupons.isActive', '1')
                ->where('usercoupons.active_status', '1')
                ->where('usercoupons.coupon_id', $request->coupon_id)
                ->first();
                
            if ($coupon != '') {
                if ($coupon->coupon_percentage !== null && $coupon->coupon_value === null) {
                    // Apply discount when percentage
                    $couponDiscount = ($coupon->coupon_percentage / 100) * $subTotal;
                } elseif ($coupon->coupon_percentage === null && $coupon->coupon_value !== null) {
                    // Apply discount when fixed value
                    $couponDiscount = $coupon->coupon_value;
                }

                // Update the Usercoupons table's active_status to 0 so user not redeem coupon twich
                UserCoupon::where('active_status', '1')->where('coupon_id', $request->coupon_id)->update(['active_status' => '0']);

            } else {
                return response([
                    'success' => true,
                    'message' => 'You need to Buy this Coupon or You already used this Coupon.',
                ], 200);
            }
        }

        $tax = $request->tax;
        $deliveryFee = $request->delivery_fee;
        $orderTotal = $subTotal + $tax + $deliveryFee - $couponDiscount;

        // Create the order with all the fields
        $order = Order::create([
            'cart_id' => $getCart->id,
            'user_id' => $userId,
            'status' => 1,
            'order_sub_total' => $subTotal,
            'order_discount' => $couponDiscount,
            'order_tax' => $tax,
            'order_delivery_fee' => $deliveryFee,
            'order_total' => $orderTotal,
            'coupon_id' => $request->coupon_id,
            'reward_status' => 1,
        ]);

        // Update the Cart table's status to 2
        $getCart->update(['status' => 2]);

        return response([
            'success' => true,
            'messagecode' => '1',
            'order_id' => $order->id,
            'message' => 'Order Successfully create.',
        ], 200);
    }

}
