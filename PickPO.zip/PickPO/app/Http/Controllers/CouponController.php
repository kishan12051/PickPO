<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Coupon;
use Validator;

class CouponController extends Controller
{
    public function index()
    {
        $coupons = Coupon::where('isActive','1')->get();
        return view('coupons.index', compact('coupons'));
    }

    public function create()
    {
        return view('coupons.create');
    }

    public function store(Request $request)
    {
        $rules = [
            'coupon_code' => 'required|unique:coupons,coupon_code',
            'coupon_type' => 'required|in:value,percentage',
            'coupon_value' => 'nullable|required_if:coupon_type,value|numeric',
            'coupon_percentage' => 'nullable|required_if:coupon_type,percentage|numeric|min:1|max:100',
            'coupon_expiry_date' => 'required|date_format:Y-m-d',
            'reward_point' => 'required|integer|min:0',
        ];

        $messages = [
            'required' => 'The :attribute field is required.',
            'unique' => 'The :attribute has already been taken.',
            'required_if' => 'The :attribute field is required when Coupon Type is :value.',
            'numeric' => 'The :attribute must be a number.',
            'in' => 'Invalid :attribute value.',
            'date_format' => 'Invalid :attribute format. Use Y-m-d format.',
            'min' => 'The :attribute must be at least :min.',
            'max' => 'The :attribute may not be greater than :max.',
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            return redirect()->route('coupons.create')
                ->withErrors($validator)
                ->withInput();
        }

        // Validation passed, try to create and save a new Coupon instance
        $coupon = new Coupon();
        $coupon->coupon_code = $request->input('coupon_code');
        $coupon->coupon_value = ($request->input('coupon_type') == 'value') ? $request->input('coupon_value') : null;
        $coupon->coupon_percentage = ($request->input('coupon_type') == 'percentage') ? $request->input('coupon_percentage') : null;
        $coupon->coupon_expiry_date = $request->input('coupon_expiry_date');
        $coupon->reward_point = $request->input('reward_point');
        
        // Check if the data is being saved correctly
        if ($coupon->save()) {
            return redirect()->route('coupons.index')->with('success', 'Coupon created successfully.');
        } else {
            return redirect()->route('coupons.create')->with('error', 'Coupon could not be saved.');
        }
    }

    public function show($id)
    {
        $coupon = Coupon::find($id);
        return view('coupons.show', compact('coupon'));
    }

    public function edit($id)
    {
        $coupon = Coupon::find($id);
        return view('coupons.edit', compact('coupon'));
    }

    public function update(Request $request, $id)
    {
        $rules = [
            'coupon_code' => 'required|unique:coupons,coupon_code,' . $id,
            'coupon_type' => 'required|in:value,percentage',
            'coupon_value' => 'nullable|required_if:coupon_type,value|numeric',
            'coupon_percentage' => 'nullable|required_if:coupon_type,percentage|numeric|min:1|max:100',
            'coupon_expiry_date' => 'required|date_format:Y-m-d',
            'reward_point' => 'required|integer|min:0',
        ];

        $messages = [
            'required' => 'The :attribute field is required.',
            'unique' => 'The :attribute has already been taken.',
            'required_if' => 'The :attribute field is required when Coupon Type is :value.',
            'numeric' => 'The :attribute must be a number.',
            'in' => 'Invalid :attribute value.',
            'date_format' => 'Invalid :attribute format. Use Y-m-d format.',
            'min' => 'The :attribute must be at least :min.',
            'max' => 'The :attribute may not be greater than :max.',
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            return redirect()->route('coupons.edit', $id)
                ->withErrors($validator)
                ->withInput();
        }

        $coupon = Coupon::find($id);

        if (!$coupon) {
            return redirect()->route('coupons.index')->with('error', 'Coupon not found.');
        }

        $coupon->coupon_code = $request->input('coupon_code');
        $coupon->coupon_value = ($request->input('coupon_type') == 'value') ? $request->input('coupon_value') : null;
        $coupon->coupon_percentage = ($request->input('coupon_type') == 'percentage') ? $request->input('coupon_percentage') : null;
        $coupon->coupon_expiry_date = $request->input('coupon_expiry_date');
        $coupon->reward_point = $request->input('reward_point');

        if ($coupon->save()) {
            return redirect()->route('coupons.index')->with('success', 'Coupon updated successfully.');
        } else {
            return redirect()->route('coupons.edit', $id)->with('error', 'Coupon could not be updated.');
        }
    }

    public function destroy($id)
    {
        $coupon = Coupon::find($id);
        if (!$coupon) {
            return redirect()->route('coupons.index')->with('error', 'Coupon not found');
        }
        $coupon = Coupon::where('id', $coupon->id)->update([
            "isActive" => ($coupon->isActive==1) ? 1 : 0,
        ]);
        return back();
    }

}
