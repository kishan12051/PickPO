<?php

return [

    'base_url' => env('BASE_URL'),
];
