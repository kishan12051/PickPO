<?php

return [

    'guest_email' => env('GUEST_EMAIL'),
    'guest_password' => env('GUEST_PASSWORD'),
];
