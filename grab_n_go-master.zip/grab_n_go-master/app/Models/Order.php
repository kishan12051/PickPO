<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $table = 'order';
     protected $fillable = [
        'id','cart_id','status','user_id','order_sub_total', 'order_discount', 'order_tax', 'order_delivery_fee', 'order_total', 'coupon_id'
    ];
}
