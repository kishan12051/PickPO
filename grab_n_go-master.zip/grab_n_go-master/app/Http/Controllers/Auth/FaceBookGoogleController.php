<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FaceBookGoogleController extends Controller
{

    public function faceBookGoogleRegistarion(Request $request)
    {

        if (isset($request->email)) {
            //validation in facebook and google API
            $validation = Validator::make($request->all(), [
                'email' => 'required|email|max:255',
            ]);

            if ($validation->fails()) {

                //Return the validation error
                $fieldsWithErrorMessagesArray = $validation->messages()->get('*');
                return $fieldsWithErrorMessagesArray;

            } else {

                $get_user = User::select()
                    ->where('email', $request->email)
                    ->first();
                if (isset($get_user)) {
                    $token = $get_user->createToken('API Token')->accessToken;

                    return response()->json([
                        'success' => true,
                        "code" => 1,
                        'message' => "Registration is successfully done",
                        'user' => $get_user,
                        'token' => $token,
                    ], 200);
                } else {
                    return response()->json([
                        'message' => "User not registrer",
                    ], 200);
                }
            }
        } 
        else {
            $validation = Validator::make($request->all(), [
                'email' => 'required|email|max:255',
            ]);
            if ($validation->fails()) {

                //Return the validation error
                $fieldsWithErrorMessagesArray = $validation->messages()->get('*');
                return $fieldsWithErrorMessagesArray;
            }

        }
    }
}
