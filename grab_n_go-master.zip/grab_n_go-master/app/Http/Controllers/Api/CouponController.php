<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserCoupon;
use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class CouponController extends Controller
{
    public function generateCoupon(Request $request)
    {
        $request->validate([
            'reward_point' => 'required|integer|min:1',
            'type' => 'required|in:percentage,value',
        ]);

        $user = Auth::user();
        $rewardPoints = $request->reward_point;

        // Check if the discount percentage are less than 100% for percentage-based coupons 
        if ($request->type === 'percentage' && $request->reward_point > 20000) {
            return response()->json([
                'message' => 'Reward points are more them 20,000. Percentage-based coupons are not allowed.',
            ], 400);
        }

        if ($user->reward_points < $rewardPoints) {
            return response()->json([
                'message' => 'Insufficient reward points to create a coupon.',
            ], 400);
        }

        if ($request->type === 'percentage') {

            $exchangeRate = 0.005; // here 1 reward point = 0.005%
            $couponPercentage = $rewardPoints * $exchangeRate;
            $couponValueInRupees = null;
        } else {
            $exchangeRate = 0.1; // here 1 reward point = 0.10 Rs
            $couponValueInRupees = $rewardPoints * $exchangeRate;
            $couponPercentage = null; 
        }

        $user->decrement('reward_points', $rewardPoints);

        $couponCode = $this->generateUniqueCouponCode();

        $coupon = new Coupon([
            'coupon_value' => $couponValueInRupees,
            'coupon_percentage' => $couponPercentage,
            'coupon_code' => $couponCode,
        ]);
        $coupon->save();

        $responseData = [
            'message' => 'Coupon generated successfully',
            'coupon' => [
                'user_id' => $user->id,
                'coupon_code' => $couponCode,
                'coupon_value' => $couponValueInRupees,
                'coupon_percentage' => $couponPercentage,
                'type' => $request->type,
            ],
        ];

        return response()->json($responseData, 201);
    }

    private function generateUniqueCouponCode()
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $couponCode = '';
        for ($i = 0; $i < 10; $i++) {
            $couponCode .= $characters[rand(0, strlen($characters) - 1)];
        }

        if (Coupon::where('coupon_code', $couponCode)->where('isActive','1')->exists()) {
            return $this->generateUniqueCouponCode();
        }

        return $couponCode;
    }
    
    public function detailsCoupon(Request $request)
    {
        $coupon = Coupon::where('coupon_code', $request->coupon_code)->where('isActive','1')->first();
        if (!$coupon) {
            return response()->json(['message' => 'Coupon not found'], 404);
        }
        $couponDetails = [
            'coupon_code' => $coupon->coupon_code,
        ];
    
        if ($coupon->coupon_value !="" && $coupon->coupon_percentage == null) {
            $couponDetails['coupon_value'] = $coupon->coupon_value;
            $couponDetails['type'] = 'Value';
            // $couponDetails['coupon_percentage'] = null;
        } else {
            $couponDetails['coupon_percentage'] = $coupon->coupon_percentage;
            $couponDetails['type'] = 'Percentage';
            // $couponDetails['coupon_value'] = null;
        }
        return response()->json(['coupon_details' => $couponDetails], 200);
    }

    public function displayCoupon()
    {
        $userId = Auth::user()->id;

        // Retrieve all coupons
        $allCoupons = Coupon::where('isActive', '1')->get();

        if ($allCoupons->isEmpty()) {
            return response()->json(['message' => 'No active coupons found'], 404);
        }

        $couponList = [];

        foreach ($allCoupons as $coupon) {

            $hasPurchased = UserCoupon::where('user_id', $userId)
                ->where('coupon_id', $coupon->id)
                ->where('active_status', '1')
                ->exists();

            $hasUsed = UserCoupon::where('user_id', $userId)
                ->where('coupon_id', $coupon->id)
                ->where('active_status', '0')
                ->exists();

            if (!$hasPurchased && !$hasUsed) {
                $couponDetails = [
                    'coupon_code' => $coupon->coupon_code,
                ];

                if ($coupon->coupon_value !== null) {
                    $couponDetails['coupon_value'] = $coupon->coupon_value;
                    $couponDetails['type'] = 'Value';
                } else {
                    $couponDetails['coupon_percentage'] = $coupon->coupon_percentage." %";
                    $couponDetails['type'] = 'Percentage';
                }

                $couponList[] = $couponDetails;
            }
        }

        return response()->json(['active_coupons' => $couponList], 200);
    }

    public function buyCoupon(Request $request)
    {
        $request->validate([
            'coupon_id' => 'required|exists:coupons,id,isActive,1',
        ]);

        $user = Auth::user();
        $couponId = $request->coupon_id;
        $coupon = Coupon::where('id', $couponId)->where('isActive', '1')->first();
    
        if (!$coupon) {
            return response()->json(['message' => 'Coupon not found or not active'], 404);
        }

        // Check if the user has previously purchased and not used this coupon
        $hasPurchasedNotUsed = UserCoupon::where('user_id', $user->id)
            ->where('coupon_id', $coupon->id)
            ->where('active_status', '1')
            ->exists();

        if ($hasPurchasedNotUsed) {
            return response()->json(['message' => 'You have already purchased this coupon and not used it'], 400);
        }

        if ($coupon->reward_point > 0) {
            if ($user->reward_points < $coupon->reward_point) {
                return response()->json(['message' => 'Insufficient reward points to buy this coupon'], 400);
            }
            $user->decrement('reward_points', $coupon->reward_point);
        }

        UserCoupon::create([
            'user_id' => $user->id,
            'coupon_id' => $coupon->id,
            'active_status' => '1',
        ]);

        return response()->json(['message' => 'Coupon purchased successfully'], 200);
    }
    

}
