<?php

namespace App\Http\Controllers\Api;

use App\Models\Address;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\State;
use Illuminate\Support\Facades\Validator;
use Auth;

class AddressController extends Controller
{
	public function addAddress(Request $request)
	{
		$userId = Auth::user()->id;
		$validation = Validator::make($request->all(), [
			'first_name' => 'required',
			'last_name' => 'required',
			'lat' => 'required',
			'long' => 'required',
			'state' => 'required',
			'full_address' => 'required',
		]);

		if ($validation->fails()) {
			return response()->json([
				'success' => false,
				'message' => 'Validation error',
				'errors' => $validation->errors(),
			], 400);
		}

		// Check if the "id" field is present in the request
		if ($request->has('id')) {
			$addressId = $request->input('id');
			$address = Address::where('isActive', '1')->find($addressId);
			
			if (!$address) {
				return response()->json([
					'success' => false,
					'message' => 'Address not found.',
				], 404);
			}

			$address->first_name = $request->input('first_name');
			$address->last_name = $request->input('last_name');
			$address->lat = $request->input('lat');
			$address->long = $request->input('long');
			$address->full_address = $request->input('full_address');

			// Check if the state already exists in the State table
			$state = State::where('state', $request->input('state'))->first();

			if ($state) {
				$address->state_id = $state->id;
			} else {
				// State doesn't exist, create it
				$newState = State::create([
					'state' => $request->input('state'),
					'status' => 1
				]);

				$address->state_id = $newState->id;
			}

			// Save the updated address
			$address->save();

			return response()->json([
				'success' => true,
				'message' => 'Address updated successfully.',
			], 200);

		} else {
			// It's a create operation since "id" is not present

			if (Auth::user()->is_admin != 2) {
				// Check if the address with the same data already exists
				$addressExists = Address::where([
					'first_name' => $request->first_name,
					'last_name' => $request->last_name,
					'lat' => $request->lat,
					'long' => $request->long,
					'state_id' => $request->state_id,
					'full_address' => $request->full_address,
				])->where('isActive', '1')->exists();

				if ($addressExists) {
					return response()->json([
						'success' => false,
						'message' => 'Address already exists with the same data.',
					], 409);
				}

				if ($userId && $request->lat && $request->long != '' && $request->state != '' && $request->full_address != '' && $request->first_name != '' && $request->last_name != '') {
					$userExist = Address::where('user_id', $userId)->where('isActive', '1')->exists();

					if ($userExist != '') {
						$checkAddress = Address::where('user_id', $userId)
							->where('first_name', $request->first_name)
							->where('last_name', $request->last_name)
							->where('lat', $request->lat)
							->where('long', $request->long)
							->where('full_address', $request->full_address)
							->where('isActive', '1')
							->exists();

						if ($checkAddress != '') {
							return response([
								'success' => true,
								'message' => 'Address already exists.'
							], 200);
						} else {
							$stateExist = State::where('state', $request->state)->exists();

							if ($stateExist == 1) {
								$stateExistData = State::where('state', $request->state)->first();
								Address::create([
									'user_id' => $userId,
									'first_name' => $request->first_name,
									'last_name' => $request->last_name,
									'lat' => isset($request->lat) ? $request->lat : '',
									'long' => isset($request->long) ? $request->long : '',
									'state_id' => $stateExistData->id,
									'full_address' => isset($request->full_address) ? $request->full_address : '',
									'default_address' => '0',
								]);

								return response([
									'success' => true,
									'message' => 'New Address stored successfully.'
								], 200);
							} else {
								// State is not exist then add the new state.
								$state = State::create([
									'state' => $request->state,
									'status' => 1
								]);

								Address::create([
									'user_id' => $userId,
									'first_name' => $request->first_name,
									'last_name' => $request->last_name,
									'lat' => isset($request->lat) ? $request->lat : '',
									'long' => isset($request->long) ? $request->long : '',
									'state_id' => $state->id,
									'full_address' => isset($request->full_address) ? $request->full_address : '',
									'default_address' => '0',
								]);

								return response([
									'success' => true,
									'message' => 'New Address stored successfully.'
								], 200);
							}
						}
					} else {
						$stateExist = State::where('state', $request->state)->exists();

						if ($stateExist == 1) {
							$stateExistData = State::where('state', $request->state)->first();
							Address::create([
								'user_id' => $userId,
								'first_name' => $request->first_name,
								'last_name' => $request->last_name,
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $stateExistData->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '1',
							]);

							return response([
								'success' => true,
								'message' => 'Address stored successfully.'
							], 200);
						} else {
							// State is not exist then add the new state.
							$state = State::create([
								'state' => $request->state,
								'status' => 1
							]);

							Address::create([
								'user_id' => $userId,
								'first_name' => $request->first_name,
								'last_name' => $request->last_name,
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $state->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '1',
							]);

							return response([
								'success' => true,
								'message' => 'Address stored successfully.'
							], 200);
						}
					}
				}
			} else {
				if ($userId && $request->lat && $request->long != '' && $request->state != '' && $request->full_address != '') {
					$userExist = Address::where('user_id', $userId)->where('isActive', '1')->exists();

					if ($userExist == '') {
						$stateExist = State::where('state', $request->state)->exists();

						if ($stateExist == 1) {
							$stateExistData = State::where('state', $request->state)->first();
							$user = Address::create([
								'user_id' => $userId,
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $stateExistData->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '1',
							]);

							return response([
								'success' => true,
								'message' => 'Guest Address stored successfully.'
							], 200);
						} else {
							$state = State::create([
								'state' => $request->state,
								'status' => 1
							]);

							Address::create([
								'user_id' => $userId,
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $state->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '0',
							]);

							return response([
								'success' => true,
								'message' => 'Guest Address stored successfully.'
							], 200);
						}
					} else {
						$stateExist = State::where('state', $request->state)->exists();

						if ($stateExist == 1) {
							$stateExistData = State::where('state', $request->state)->first();
							$user = Address::where('user_id', $userId)->update([
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $stateExistData->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '1',
							]);
						} else {
							$state = State::create([
								'state' => $request->state,
								'status' => 1
							]);

							Address::create([
								'user_id' => $userId,
								'lat' => isset($request->lat) ? $request->lat : '',
								'long' => isset($request->long) ? $request->long : '',
								'state_id' => $state->id,
								'full_address' => isset($request->full_address) ? $request->full_address : '',
								'default_address' => '0',
							]);
						}

						return response([
							'success' => true,
							'message' => 'Guest Address updated successfully.'
						], 200);
					}
				}
			}
		}
	}

	public function getAddress(Request $request)
	{

		if (Auth::user()->is_admin != 2) {

			if (isset($request->user_id)) {

				if (Auth::user()->id == $request->user_id) {
					$userExist = Address::where('user_id', $request->user_id)->where('isActive', '1')->exists();
					if ($userExist == 1) {

						$getAddress = Address::select('id','first_name','last_name','user_id','lat','long','state_id','full_address','created_at','updated_at','default_address')->where('user_id', $request->user_id)->where('isActive', '1')->get();

						return response(
							[
								'getaddress' => $getAddress,
								'success' => true,
								'message' => 'successfully.'
							],
							200
						);
					}
				} else {

					return response(
						[
							'success' => true,
							'message' => 'User address in not available.'
						],
						200
					);
				}
			} else {
				$validation = Validator::make($request->all(), [
					'user_id' => 'required',
				]);

				if ($validation->fails()) {
					$fieldsWithErrorMessagesArray = $validation->messages()->get('*');
					return $fieldsWithErrorMessagesArray;
				}
			}
		} else {
			return response(
				[
					'message' => 'User Unauthenticated'
				],
				200
			);
		}
	}
	public function updateAddress(Request $request)
	{

		$userId = Auth::user()->id;

		$userExist = Address::where('user_id', $userId)->where('isActive', '1')->exists();
		if ($userExist == 1) {
			if (isset($request->address_id)) {


				$addressExist = Address::where('id', $request->address_id)->where('user_id', $userId)->where('isActive', '1')->exists();
				if ($addressExist == 1) {
					Address::where('user_id', $userId)->update(['default_address' => '0']);
					Address::where('id', $request->address_id)->where('user_id', $userId)->update(['default_address' => '1']);
					return response(
						[
							'success' => true,
							'messagecode' => 1,
							'message' => 'Address update successfully.'
						],
						200
					);
				} else {
					return response(
						[
							'success' => true,
							'message' => 'User and address_id is not available.'
						],
						200
					);
				}
			} else {
				$validation = Validator::make($request->all(), [
					'address_id' => 'required',
				]);

				if ($validation->fails()) {
					$fieldsWithErrorMessagesArray = $validation->messages()->get('*');
					return $fieldsWithErrorMessagesArray;
				}
			}
		}
	}
	
	public function deleteAddress(Request $request)
	{
		$userId = Auth::user()->id;
		if (isset($request->address_id)) {
			$addressExist = Address::where('id', $request->address_id)->where('user_id', $userId)->where('isActive', '1')->first();

			if ($addressExist) {
				if ($addressExist->default_address == 1) {
					return response([
						'success' => false,
						'messagecode' => 2,
						'message' => 'Cannot delete the address as it the is default address.'
					], 200);
				}

				Address::where('id', $request->address_id)->update(["isActive" => ($request->isActive == 1) ? 0 : 1,]);

				return response([
					'success' => true,
					'messagecode' => 1,
					'message' => 'Address deleted successfully.'
				], 200);
			} else {
				return response([
					'success' => false,
					'message' => 'Address not found or is inactive.'
				], 200);
			}
		} else {
			$validation = Validator::make($request->all(), [
				'address_id' => 'required',
			]);

			if ($validation->fails()) {
				$fieldsWithErrorMessagesArray = $validation->messages()->get('*');
				return $fieldsWithErrorMessagesArray;
			}
		}
	}

}
