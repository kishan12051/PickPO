<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PrivacyPolicy;

class PrivacyPolicyController extends Controller
{
    public function index()
    {
        $privacyPolicy = PrivacyPolicy::where('id', 1)->get();

        $privacyPolicyData= $privacyPolicy[0]['privacy_policy_editor'];

        return view('privacypolicy.privacypolicy',compact('privacyPolicyData'));
    }

    public function edit($id)
    {
        $privacyPolicy = PrivacyPolicy::where('id', 1)->get();

        return view('privacypolicy.privacypolicyedit', compact('privacyPolicy'));
    }

    public function update(Request $request)
    {
        PrivacyPolicy::where('id', 1)->update(array(
            'privacy_policy_editor' => $request->privacy_policy_editor,
        ));

        $privacyPolicy = PrivacyPolicy::where('id', 1)->get();
        return view('privacypolicy.privacypolicyedit', compact('privacyPolicy'));
    }
}
